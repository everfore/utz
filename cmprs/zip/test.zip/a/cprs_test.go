package cmprs

import (
	"testing"
)

func TestUntar(t *testing.T) {
	Untar("./tar/all.tar")
}
