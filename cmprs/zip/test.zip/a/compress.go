package cmprs

import (
	"archive/tar"
	"fmt"
	"github.com/shaalx/goutils"
	"io"
	"os"
)

func Untar(tar_filename string) {
	file, err := os.OpenFile(tar_filename, os.O_RDONLY, 0444)
	defer file.Close()
	if goutils.CheckErr(err) {
		return
	}
	tr := tar.NewReader(file)
	for {
		hr, err := tr.Next()
		if err == io.EOF {
			break
		}
		fmt.Println(hr.FileInfo().Name())
		of, err := os.OpenFile(hr.Name, os.O_CREATE|os.O_WRONLY, 0666)
		if goutils.CheckErr(err) {
			continue
		}
		io.Copy(of, tr)
		fmt.Println("------------\n---------------")
	}
}
